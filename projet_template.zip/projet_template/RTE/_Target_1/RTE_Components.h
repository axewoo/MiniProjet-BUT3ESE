
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'test' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f7xx.h"

/* ARM::CMSIS:RTOS2:Keil RTX5&Source@5.9.0 */
#define RTE_CMSIS_RTOS2                 /* CMSIS-RTOS2 */
        #define RTE_CMSIS_RTOS2_RTX5            /* CMSIS-RTOS2 Keil RTX5 */
        #define RTE_CMSIS_RTOS2_RTX5_SOURCE     /* CMSIS-RTOS2 Keil RTX5 Source */
/* Keil::CMSIS Driver:Ethernet MAC@1.12.0 */
#define RTE_Drivers_ETH_MAC0            /* Driver ETH_MAC0 */
/* Keil::CMSIS Driver:Ethernet PHY:LAN8742A@1.3.0 */
#define RTE_Drivers_PHY_LAN8742A        /* Driver PHY LAN8742A */
/* Keil::Device:STM32Cube Framework:Classic@1.3.0 */
#define RTE_DEVICE_FRAMEWORK_CLASSIC
/* Keil::Device:STM32Cube HAL:Common@1.3.0 */
#define RTE_DEVICE_HAL_COMMON
/* Keil::Device:STM32Cube HAL:Cortex@1.3.0 */
#define RTE_DEVICE_HAL_CORTEX
/* Keil::Device:STM32Cube HAL:DMA2D@1.3.0 */
#define RTE_DEVICE_HAL_DMA2D
/* Keil::Device:STM32Cube HAL:DMA@1.3.0 */
#define RTE_DEVICE_HAL_DMA
/* Keil::Device:STM32Cube HAL:GPIO@1.3.0 */
#define RTE_DEVICE_HAL_GPIO
/* Keil::Device:STM32Cube HAL:I2C@1.3.0 */
#define RTE_DEVICE_HAL_I2C
/* Keil::Device:STM32Cube HAL:LTDC@1.3.0 */
#define RTE_DEVICE_HAL_LTDC
/* Keil::Device:STM32Cube HAL:PWR@1.3.0 */
#define RTE_DEVICE_HAL_PWR
/* Keil::Device:STM32Cube HAL:RCC@1.3.0 */
#define RTE_DEVICE_HAL_RCC
/* Keil::Device:STM32Cube HAL:SDRAM@1.3.0 */
#define RTE_DEVICE_HAL_SDRAM
/* Keil::Device:STM32Cube HAL:UART@1.3.0 */
#define RTE_DEVICE_HAL_UART
/* Keil::Device:Startup@1.2.5 */
#define RTE_DEVICE_STARTUP_STM32F7XX    /* Device Startup for STM32F7 */
/* Keil::Network&MDK-Plus:CORE&IPv4 Release@7.19.0 */
#define RTE_Network_Core                /* Network Core */
          #define RTE_Network_IPv4                /* Network IPv4 Stack */
          #define RTE_Network_Release             /* Network Release Version */
/* Keil::Network&MDK-Plus:Interface:ETH@7.19.0 */
#define RTE_Network_Interface_ETH_0     /* Network Interface ETH 0 */

/* Keil::Network&MDK-Plus:Socket:UDP@7.19.0 */
#define RTE_Network_Socket_UDP          /* Network Socket UDP */
/* Segger::Graphics&MDK-Pro:CORE@6.32.3 */
#define RTE_Graphics_Core               /* Graphics Core */
/* Segger::Graphics&MDK-Pro:Input Device:Touchscreen@6.32.3 */
#define RTE_Graphics_Touchscreen        /* Graphics Input Device Touchscreen */


#endif /* RTE_COMPONENTS_H */
